<?php 
    include "connect.php";
    $sql = "SELECT * FROM admin_info ORDER BY counter ASC";
    $stmt = $con -> prepare($sql);
    $stmt -> execute();
    $result = $stmt -> get_result();
    $i = 1;
    while ($row = $result -> fetch_assoc()):
?>
    <tr>
        <td><?= $i?></td>
        <td class="nama text-break" style="padding-left: 30px;"><?= $row['nama_admin'] ?></td>
        <td class="aktv" style="padding-left: -40px;"><?= $row['admin_email'] ?></td>
        <?php if ($_SESSION['login'] == "Admin Utama"): ?>
            <?php if ($row['nama_admin'] == "Admin Utama"): ?>
                <td></td>
            <?php else: ?>
                <td>
                <?php if ($row['admin_status'] == "ACTIVE"): ?>
                    <select class="form-select form-select-<?= $i ?>" id="<?= $row['admin_email'] ?>" aria-label="Floating label select example" style="background-color: green;  color: white; 
        font-weight: bold;" onchange="changeSelected('<?= $i ?>', '<?= $row['admin_email'] ?>')">
                        <option selected hidden value="<?= $row['admin_status'] ?>"><?= $row['admin_status'] ?></option>
                        <option value="NOT ACTIVE" style="background-color: #FFCC70; color: red; 
        font-weight: bold;">NOT ACTIVE</option>
                <?php else: ?>
                    <select class="form-select form-select-<?= $i ?>" id="<?= $row['admin_email'] ?>" aria-label="Floating label select example" style="background-color: red;  color: white; 
        font-weight: bold;" onchange="changeSelected('<?= $i ?>', '<?= $row['admin_email'] ?>')">
                        <option selected hidden value="<?= $row['admin_status'] ?>"><?= $row['admin_status'] ?></option>
                        <option value="ACTIVE" style="background-color: #FFCC70; color: green; 
        font-weight: bold;">ACTIVE</option>
                <?php endif ?>
                </td>
            <?php endif ?>
        <?php else: ?>
            <?php if ($row['admin_status'] == "ACTIVE"): ?>
                <td style="color: green; font-weight: bold;"><?= $row['admin_status'] ?></td>
            <?php else: ?>
                <td style="color: red; font-weight: bold;"><?= $row['admin_status'] ?></td>
            <?php endif ?>
        <?php endif ?>
    </tr>
    <?php $i++ ?>
<?php endwhile; ?>