<?php
include 'connect.php';

$user_email = $_POST['userEmail'];

// check table user_dewasa
$result_dewasa = mysqli_query($con, "SELECT * FROM user_dewasa_info WHERE user_email = '$user_email");

// check table user_anak
$result_anak = mysqli_query($con, "SELECT * FROM user_anak_info WHERE user_email = '$user_email'");

$query2 = mysqli_query($con, "SELECT * FROM reset_verification WHERE user_email = '$user_email'");
$row = mysqli_fetch_assoc($query2);
$status = $row['reset_status'];

if ((mysqli_num_rows($result_dewasa) === 1) || (mysqli_num_rows($result_anak) === 1)) {
    $newPass = password_hash($_POST['newPass'], PASSWORD_DEFAULT);
    if ((mysqli_num_rows($result_dewasa) > 0) && ($status == "1")) {
        $query3 = mysqli_query($con, "UPDATE `user_dewasa_info` SET `password`='$newPass' WHERE `user_email` = '$user_email'");
    } elseif ((mysqli_num_rows($result_anak) > 0) && ($status == "1")) {
        $query3 = mysqli_query($con, "UPDATE `user_anak_info` SET `password`='$newPass' WHERE `user_email` = '$user_email'");
    }
    $query4 = mysqli_query($con, "UPDATE `reset_verification` SET `reset_code`='0', `reset_status`='0' WHERE `user_email` = '$user_email'");  
} else {
    // update user log
    $currentTimestamp = date('Y-m-d H:i:s');
    $activity = 'Reset Password gagal.';
    $sql = "INSERT INTO user_log (
        time, user_name, activity)
        VALUES (
            '$currentTimestamp','$email','$activity')";
    $stmt = $con -> prepare($sql);
    $stmt -> execute();

    $em = "Reset password gagal. Silahkan coba lagi.";
    # response array
    $res = array('error' => 1, 'em'=> $em);
    echo json_encode($res);
    exit;
}

// update user log
$currentTimestamp = date('Y-m-d H:i:s');
$activity = 'Reset Password berhasil.';
$sql = "INSERT INTO user_log (
    time, user_name, activity)
    VALUES (
        '$currentTimestamp','$email','$activity')";
$stmt = $con -> prepare($sql);
$stmt -> execute();

$sm = "Password berhasil diubah.";
# response array
$res = array('error' => 0, 'sm'=> $sm);
echo json_encode($res);
?>