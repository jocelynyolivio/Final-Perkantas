<?php
include 'connect.php';

$user_email = $_POST['userEmail'];
$otp = $_POST['otpIn'];

$query1 = mysqli_query($con, "SELECT reset_code FROM reset_verification WHERE user_email = '$user_email'");

$row = mysqli_fetch_assoc($query1);
$otpCheck = $row['reset_code'];

if ((mysqli_num_rows($query1) === 1) && ($otpCheck == $otp)) {
    $query2 = mysqli_query($con, "UPDATE `reset_verification` SET `reset_status`='1' WHERE `user_email` = '$user_email'");  
    
} else {
    // update user log
    $currentTimestamp = date('Y-m-d H:i:s');
    $activity = 'Kode OTP tidak valid.';
    $sql = "INSERT INTO user_log (
        time, user_name, activity)
        VALUES (
            '$currentTimestamp','$email','$activity')";
    $stmt = $con -> prepare($sql);
    $stmt -> execute();

    $em = "Kode OTP tidak valid.";
    # response array
    $res = array('error' => 1, 'em'=> $em);
    echo json_encode($res);
    exit;
}

// update reset log
// update user log
$currentTimestamp = date('Y-m-d H:i:s');
$activity = 'Kode OTP telah divalidasi.';
$sql = "INSERT INTO user_log (
    time, user_name, activity)
    VALUES (
        '$currentTimestamp','$email','$activity')";
$stmt = $con -> prepare($sql);
$stmt -> execute();

$sm = "Silahkan masukkan password baru anda.";
# response array
$res = array('error' => 0, 'sm'=> $sm);
echo json_encode($res);


?>