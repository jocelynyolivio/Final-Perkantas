<?php
    header("location:login");
?>