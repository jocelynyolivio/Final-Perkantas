<?php
 if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

if (!isset ($_SESSION["konselor_email"])){
    header("location: login.php");
    exit();
}

include "../connect.php";
include "../header.php";

$konselor_email=$_SESSION["konselor_email"];
$row = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM konselor_info WHERE konselor_email='$konselor_email'"));

?>
<script src="../css/jquery.js"></script>
<script src="../css/bootstrap.js"></script>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dosis&display=swap" rel="stylesheet">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300&display=swap" rel="stylesheet">
<style>

	body {
		background-image: url(background/halftone.png);
		font-family: 'Dosis', sans-serif;
		position: relative;
		width: 100%;
	}

	/* tulisan data diri */
	h1 {
		font-weight: bold;
		font-family: 'Titillium Web', sans-serif;
	}

	/* konten tabel */
	.datadiri .row {
		font-size: 16px;
		font-weight: normal;
	}

	input::-webkit-input-placeholder {
		color: black;
	}

	input:focus::-webkit-input-placeholder {
		color: #888;
	}

	.container .submit {
		position: absolute;
		left: 45%;
	}

	

	.datadiri .alert .bintang {
		text-align: center;
	}

</style>

<div class="container datadiri">
	<h1>Data Diri</h1>
	<section class="section contact-section" id="next">
		<div class="row">
			<div class="col-md-12" data-aos="fade-up" data-aos-delay="100">

				<form action="#" method="post" class="bg-white p-md-5 p-4 mb-5 border">
					<div class="row">
						<div class="col-md-6 form-group">
							<input type="hidden" id="konselor_email" class="form-control " value="<?= $row['konselor_email']; ?>" required />
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 form-group">
							<label class="text-black font-weight-bold" for="nama">Nama Lengkap</label>
							<input type="text" id="nama" class="form-control " value="<?= $row['konselor_nama']; ?>" required />
						</div>
						<div class="col-md-6 form-group">
							<label class="text-black font-weight-bold" for="umur">Umur</label>
							<input type="text" id="umur" class="form-control " value="<?= $row['umur']; ?>" required />
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 form-group">
							<label class="text-black font-weight-bold" for="handphone">Nomor Telepon</label>
							<input type="text" id="handphone" class="form-control " value="<?= $row['handphone']; ?>" required />
						</div>
						<div class="col-md-6 form-group">
							<label class="text-black font-weight-bold" for="email_pribadi">Email Pribadi</label>
							<input type="text" id="email_pribadi" class="form-control " value="<?= $row['email_pribadi']; ?>" required />
						</div>
					</div>

					<div class="row">
						<div class="col-md-6 form-group">
							<label class="text-black font-weight-bold" for="gelar">Gelar</label>
							<input type="text" id="gelar" class="form-control " value="<?= $row['gelar']; ?>" required />
						</div>
						<div class="col-md-6 form-group">
							<label for="type" class="font-weight-bold text-black">Gender</label>
							<div class="field-icon-wrap">
								<div class="icon"><span class="ion-ios-arrow-down"></span></div>
								<select required name="gender" id="gender" class="form-control">
									<?php
									if ($row['jenis_kelamin']) {
										if ($row['jenis_kelamin'] == 'L') {
											echo '
											<option value="L" selected>Laki-laki</option>
											<option value="P">Perempuan</option>
											';
										} else {
											echo '
											<option value="L">Laki-laki</option>
											<option value="P" selected>Perempuan</option>
											';
										}
									} else echo '
										<option hidden value="">Select</option>
									<option value="L">Laki-laki</option>
									<option value="P">Perempuan</option>
									';

									?>

								</select>
							</div>
						</div>
					</div>
                    <div class="row">
						<div class="col-md-12 form-group">
							<label class="text-black font-weight-bold" for="alamat">Alamat</label>
							<input type="text" id="alamat" class="form-control " value="<?= $row['alamat']; ?>" required />
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-12 form-group">
							<button type="submit" value="Submit" id="save" class="btn btn-primary submit">Submit</button>
							<br><br>
						</div>
					</div>
				</form>
			</div>
		</div>
</div>

<script>
	$(document).ready(function() {
		// alert("READYYY");
		$("#save").click(function(e) {
			var valid = this.form.checkValidity(); // for demonstration purposes only, will always b "true" here, in this case, since HTML5 validation will block this "click" event if form invalid (i.e. if "required" field "foo" is empty)
			if (valid) {
				event.preventDefault(); // stops the "normal" <form> request, so we can post using ajax instead, below
				var konselor_email =  $('#konselor_email').val();
				var nama = $('#nama').val();
				var umur = $('#umur').val();
				var handphone = $('#handphone').val();
				var email = $('#email_pribadi').val();
				var gelar = $('#gelar').val();
				var gender = $('#gender').val();
				var alamat = $('#alamat').val();
				$.ajax({
					url: 'update_profile.php',
					method: 'POST',
					data: {
						konselor_email: konselor_email,
						nama: nama,
						umur: umur,
						handphone: handphone,
						alamat: alamat,
						email: email,
						gelar: gelar,
						gender: gender
					},
					success: function(data) {
						alert("Data berhasil diupdate");
					}
				});
			}
		});
	});
</script>