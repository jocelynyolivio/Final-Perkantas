<?php 
 if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

if (!isset ($_SESSION["konselor_email"])){
    header("location: login.php");
    exit();
}

include "../connect.php";
mysqli_query($con, "UPDATE konselor_info SET konselor_nama='".$_POST['nama']."', umur='".$_POST['umur']."', handphone='".$_POST['handphone']."', email_pribadi='".$_POST['email']."', alamat='".$_POST['alamat']."', gelar='".$_POST['gelar']."', jenis_kelamin='".$_POST['gender']."' WHERE konselor_email='".$_POST['konselor_email']."'");

echo "Data berhasil diupdate ";
?>