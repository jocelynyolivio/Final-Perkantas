<?php
 if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

if (!isset ($_SESSION["konselor_email"])){
    header("location: login.php");
    exit();
}

include "../connect.php";
include "../header.php";
$konselor_email=$_SESSION["konselor_email"];
$query_bio = mysqli_query($con, "select konselor_nama, konselor_id from konselor_info where konselor_email='$konselor_email'");

$row = mysqli_fetch_array($query_bio);
$nama = $row[0];
$id_konselor = $row[1];
echo "
<div class='alert alert-success alerttop' id='hai'>
<strong>Selamat datang, " . $nama . "!  Have a great day!</strong><br>
</div>
<div>";
echo "</div><br>";

//kalok status = 0 brarti gada user yang ambil, 1 udah diambil, 2 sudah selesai
$query_jadwal_konseling = mysqli_query($con, "SELECT * FROM konselor_jadwal WHERE konselor_id=" . $id_konselor . " AND status != 2 ORDER BY tanggal, jam_awal ASC");

$jumlah_tabel = 0;

while ($row_jadwal_konseling = mysqli_fetch_assoc($query_jadwal_konseling)) {
    $jumlah_tabel = $jumlah_tabel + 1;
    $hari = $row_jadwal_konseling['tanggal'];
    $timestamp = strtotime($hari);
    $newFormatHari = date('l, d-m-Y', $timestamp);
    $jam_awal = $row_jadwal_konseling['jam_awal'];
    $jam_akhir = $row_jadwal_konseling['jam_akhir'];

    echo ' <table id="myTable' . $jumlah_tabel . '" class="table" width="100%">
   <thead>
   <th>Jadwal Konseling</th>
   <th>Nama</th>
   <th>Biodata</th>
   <th>Catatan</th>
   <th>Status</th>
   </thead>
   <br>
  ';

    $query_get_user = mysqli_query($con, "SELECT * FROM pemilihan_jadwal WHERE konselor_jadwal_id=" . $row_jadwal_konseling['konselor_jadwal_id'] . "");
    while($row_email_user = mysqli_fetch_array($query_get_user)){
        $email_user = $row_email_user['email_user'];
        $query_user_anak_info = mysqli_query($con, "SELECT * FROM user_anak_info WHERE user_email=" . $email_user . "");

        $query_user_dewasa_info = mysqli_query($con, "SELECT * FROM user_dewasa_info WHERE user_email=" . $email_user . "");
    };

    #ngecek iki user e anak ta dewasa
   while ($row_user_fix = mysqli_fetch_assoc($query_user_anak_info)) {
    $query_get_user = mysqli_query($con, "SELECT * FROM pemilihan_jadwal WHERE konselor_jadwal_id=" . $row_jadwal_konseling['konselor_jadwal_id'] . "");
    $row_email_user = mysqli_fetch_array($query_get_user);
                if ($row_user_fix['kelamin']) {
                    if ($row_user_fix['kelamin'] == '1') {
                        $gender = "Laki-Laki";
                    } else {
                        $gender = "Perempuan";
                    }
                } else {
                    $gender = "";
                }
                echo '
                <td class="jadwal">' . $newFormatHari . " | " . $jam_awal . " - " . $jam_akhir . '</td>
                <td class="nama_user">' . $row_user_fix['nama'] . '</td>
                <td>
                    <button type="button" class="btn btn-success margin small" data-toggle="modal" data-target="#exampleModal1' . $row_user_fix['user_email'] . '">Biodata</button>
                </td>
                <td>
                    <button type="button" class="btn btn-primary margin small" data-toggle="modal" data-target="#exampleModal2' . $row_user_fix['user_email'] . '">Catatan</button>
                </td>
                <td>
                    <a href="#exampleModal3' . $row_user_fix['user_email'] . '" class="trigger-btn" data-toggle="modal">
                        <i class="fas fa-check fa-2x" style="color: green; "></i>
                    </a>
                </td>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal1' . $row_user_fix['user_email'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel' . $row_user_fix['user_email'] . '" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel' . $row_user_fix['user_email'] . '">' . $row_user_fix['nama'] . '</h5>
                                
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label class="text-black font-weight-bold" for="nama">Nama Lengkap</label>
                                        <input readonly type="text" id="nama" class="form-control" value="' . $row_user_fix['nama'] . '" />
                                    </div>
                                   
                                  <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="jenis_kelamin">Jenis Kelamin</label>
                                                            <input readonly type="text" id="jenis_kelamin" class="form-control" value="' . $gender . '" />
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="pekerjaan">Nama Sekolah</label>
                                                            <input readonly type="text" id="pekerjaan" class="form-control" value="' . $row_user_fix['nama_sekolah'] . '" />
                                                        </div>
                                                        <div class="col-md-6 form-group">
                                                            <label for="type" class="font-weight-bold text-black">Suku dan Agama</label>
                                                            <input readonly type="text" id="suku_agama" class="form-control " value="'.$row_user_fix['suku_agama'].'" />
                                                        </div>
                                                       
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12 form-group">
                                                            <label class="text-black font-weight-bold" for="alamat">Alamat</label>
                                                            <input readonly type="text" id="alamat" class="form-control" value="' .  $row_user_fix['alamat'] . '" />
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="telepon">Nomor Telepon</label>
                                                            <input readonly type="text" id="telepon" class="form-control " value="'. $row_user_fix['telepon'].'" />
                                                        </div>
                                                        <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="pendidikan">Kelas</label>
                                                            <input readonly type="text" id="pendidikan" class="form-control " value="'. $row_user_fix['kelas'].'" />
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="row">
                                                      <div class="col-md-12 form-group">
                                                            <label class="text-black font-weight-bold" for="tempat_tanggal_lahir">Tempat, tanggal lahir</label>
                                                            <input readonly type="text" id="tempat_tanggal_lahir" class="form-control " value="'. $row_user_fix['tempat_tanggal_lahir'].'" />
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="row">
                                                        <div class="col-md-6 form-group">
                                                            <label for="type" class="font-weight-bold text-black">Anak ke</label>
                                                            <input readonly type="text" id="anak_ke" class="form-control " value="'. $row_user_fix['anak_ke'].'" />
                                                        </div>
                                                        <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="warganegara">Warganegara</label>
                                                            <input readonly type="text" id="warganegara" class="form-control" value="'. $row_user_fix['warganegara'].'" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal2' . $row_user_fix['user_email'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel' . $row_user_fix['user_email'] . '" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel' . $row_user_fix['user_email'] . '">' . $row_user_fix['nama'] . '</h5>
                                                
                                            </div>
                                            <div class="modal-body">
                            <div class="col-md-6 form-group">
                                </div>                                                                                         
                                    <div class="form-group">
                                        <label for="formGroupExampleInput">Catatan</label>
                                        <textarea class="form-control" id="catatan" name="catatan"></textarea required>                                                               
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" id="save" data-dismiss="modal">Close</button>
                                         <button type="button" class="btn btn-danger" data-dismiss="modal">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td></tr>';




    }
     while ($row_user_fix = mysqli_fetch_assoc($query_user_dewasa_info)) {
                if ($row_user_fix['kelamin']) {
                    if ($row_user_fix['kelamin'] == '1') {
                        $gender = "Laki-Laki";
                    } else {
                        $gender = "Perempuan";
                    }
                } else {
                    $gender = "";
                }
                              echo '
<tr>
<td class="jadwal">' . $newFormatHari . " | " . $jam_awal . " - " . $jam_akhir . '</td>
<td class="nama_user">' . $row_user_fix['nama'] . '</td>
<td>
    <button type="button" class="btn btn-success margin small" data-toggle="modal" data-target="#exampleModal1' . $row_user_fix['user_email'] . '">Biodata</button>
</td>
<td>
    <button type="button" class="btn btn-primary margin small" data-toggle="modal" data-target="#exampleModal2' . $row_user_fix['user_email'] . '">Catatan</button>
</td>
<td>
    <a href="#exampleModal3' . $row_user_fix['user_email'] . '" class="trigger-btn" data-toggle="modal">
        <i class="fas fa-check fa-2x" style="color: green; "></i>
    </a>
</td>
<!-- Modal -->
<div class="modal fade" id="exampleModal1' . $row_user_fix['user_email'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel' . $row_user_fix['user_email'] . '" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel' . $row_user_fix['user_email'] . '">' . $row_user_fix['nama'] . '</h5>
                
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label class="text-black font-weight-bold" for="nama">Nama Lengkap</label>
                        <input readonly type="text" id="nama" class="form-control" value="' . $row_user_fix['nama'] . '" />
                    </div>
                   
                  <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="jenis_kelamin">Jenis Kelamin</label>
                                            <input readonly type="text" id="jenis_kelamin" class="form-control" value="' . $gender . '" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="pekerjaan">Pekerjaan</label>
                                            <input readonly type="text" id="pekerjaan" class="form-control" value="' . $row_user_fix['pekerjaan'] . '" />
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="type" class="font-weight-bold text-black">Suku dan Agama</label>
                                            <input readonly type="text" id="suku_agama" class="form-control " value="'.$row_user_fix['suku_agama'].'" />
                                        </div>
                                       
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label class="text-black font-weight-bold" for="alamat">Alamat</label>
                                            <input readonly type="text" id="alamat" class="form-control" value="' .  $row_user_fix['alamat'] . '" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="telepon">Nomor Telepon</label>
                                            <input readonly type="text" id="telepon" class="form-control " value="'. $row_user_fix['telepon'].'" />
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="pendidikan">Pendidikan</label>
                                            <input readonly type="text" id="pendidikan" class="form-control " value="'. $row_user_fix['pendidikan'].'" />
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                      <div class="col-md-12 form-group">
                                            <label class="text-black font-weight-bold" for="tempat_tanggal_lahir">Tempat, tanggal lahir</label>
                                            <input readonly type="text" id="tempat_tanggal_lahir" class="form-control " value="'. $row_user_fix['tempat_tanggal_lahir'].'" />
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label for="type" class="font-weight-bold text-black">Anak ke</label>
                                            <input readonly type="text" id="anak_ke" class="form-control " value="'. $row_user_fix['anak_ke'].'" />
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="warganegara">Warganegara</label>
                                            <input readonly type="text" id="warganegara" class="form-control" value="'. $row_user_fix['warganegara'].'" />
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal2' . $row_user_fix['user_email'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel' . $row_user_fix['user_email'] . '" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel' . $row_user_fix['user_email'] . '">' . $row_user_fix['nama'] . '</h5>
                                
                            </div>
                            <div class="modal-body">
                            <div class="col-md-6 form-group">
                                </div>                                                                                         
                                    <div class="form-group">
                                        <label for="formGroupExampleInput">Catatan</label>
                                        <textarea class="form-control" id="catatan" name="catatan"></textarea required>                                                               
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" id="save" data-dismiss="modal">Close</button>
                                         <button type="button" class="btn btn-danger" data-dismiss="modal">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td></tr>';


    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Datatables CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css" />
    
    <!-- FONT AWESOME -->
    <script src="https://kit.fontawesome.com/acc3ee9eed.js" crossorigin="anonymous"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konselor Login - Griya Pulih Asih</title>
    <!-- ICON -->
    <link href="" rel="icon" />
    <style>
    body {
        /* background-image: url(../assets/halftone.png); */
        background-color: rgb(252, 193, 109);
        color: black;
        font-family: 'Roboto';
    }
    #hai{
        color: black;
        background-color: white;
        border: none;
        font-size: 30px;
        background-color: rgb(252, 193, 109);
    }
    #myTable{
        margin: 4vh;
        border: black;
        border-radius: 2px;
    }

    img {
        text-align: center;
    }

    .foto {
        text-align: center;
    }

    .bawah {
        margin-top: 35px;
    }

    .isibiodata {
        margin-bottom: 35px;
    }

    table {
        text-align: center;
    }

    .alerttop {
        margin-top: 20px;
        text-align: center;
    }

    .col-md-12 .alert a {
        display: inline-block;
    }

    textarea {
    resize: vertical;
}

</style>
</head>
<body>
                        
    
</body>
</html>