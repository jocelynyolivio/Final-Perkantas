<?php
 if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

if (!isset ($_SESSION["konselor_email"])){
    header("location: login.php");
    exit();
}

include "../connect.php";
include "../header.php";
$konselor_email=$_SESSION["konselor_email"];
$query_bio = mysqli_query($con, "select konselor_nama, konselor_id from konselor_info where konselor_email='$konselor_email'");

$row = mysqli_fetch_array($query_bio);
$nama = $row[0];
$id_konselor = $row[1];
echo "
<div class='alert alert-success alerttop' id='hai'>
<strong>Selamat datang, " . $nama . "!  Have a great day!</strong><br>
</div>
<div>";
echo "</div><br>";

//kalok status = 0 brarti gada user yang ambil, 1 udah diambil, 2 sudah selesai
$query_jadwal_konseling = mysqli_query($con, "SELECT * FROM konselor_jadwal WHERE konselor_id=" . $id_konselor . " AND status != 2 ORDER BY tanggal, jam_awal ASC");

$jumlah_tabel = 0;
echo '<div class="container">
    <div class="table-responsive mp-4">
    <table id="tabelEvent" class="display nowrap" style="width:100%">
   <thead>
   <th>Jadwal Konseling</th>
   <th>Nama</th>
   <th>Biodata</th>
   <th>Catatan</th>
   <th>Status</th>
   </thead>
   <tbody id="list-jadwal">
  ';
while ($row_jadwal_konseling = mysqli_fetch_assoc($query_jadwal_konseling)) {
    $jumlah_tabel = $jumlah_tabel + 1;
    $hari = $row_jadwal_konseling['tanggal'];
    $timestamp = strtotime($hari);
    $newFormatHari = date('l, d-m-Y', $timestamp);
    $jam_awal = $row_jadwal_konseling['jam_awal'];
    $jam_akhir = $row_jadwal_konseling['jam_akhir'];

    $query_get_user = mysqli_query($con, "SELECT * FROM pemilihan_jadwal WHERE konselor_jadwal_id=" . $row_jadwal_konseling['konselor_jadwal_id'] . "");
    while($row_email_user = mysqli_fetch_array($query_get_user)){
        $email_user = $row_email_user['email_user'];
        $query_user_anak_info = mysqli_query($con, "SELECT * FROM user_anak_info WHERE user_email=" . $email_user . "");

        $query_user_dewasa_info = mysqli_query($con, "SELECT * FROM user_dewasa_info WHERE user_email=" . $email_user . "");
    };

    #ngecek iki user e anak ta dewasa
   while ($row_user_fix = mysqli_fetch_assoc($query_user_anak_info)) {
    $query_get_user = mysqli_query($con, "SELECT * FROM pemilihan_jadwal WHERE konselor_jadwal_id=" . $row_jadwal_konseling['konselor_jadwal_id'] . "");
    $row_email_user = mysqli_fetch_array($query_get_user);
                if ($row_user_fix['kelamin']) {
                    if ($row_user_fix['kelamin'] == '1') {
                        $gender = "Laki-Laki";
                    } else {
                        $gender = "Perempuan";
                    }
                } else {
                    $gender = "";
                }
                echo '
                <td class="jadwal">' . $newFormatHari . " | " . $jam_awal . " - " . $jam_akhir . '</td>
                <td class="nama_user">' . $row_user_fix['nama'] . '</td>
                <td>
                    <button type="button" class="btn btn-success margin small" data-toggle="modal" data-target="#exampleModal1' . $row_user_fix['user_email'] . '">Biodata</button>
                </td>
                <td>
                    <button type="button" class="btn btn-primary margin small" data-toggle="modal" data-target="#exampleModal2' . $row_user_fix['user_email'] . '">Catatan</button>
                </td>
                <td>
                    <a href="#exampleModal3' . $row_user_fix['user_email'] . '" class="trigger-btn" data-toggle="modal">
                        <i class="fas fa-check fa-2x" style="color: green; "></i>
                    </a>
                </td>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal1' . $row_user_fix['user_email'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel' . $row_user_fix['user_email'] . '" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel' . $row_user_fix['user_email'] . '">' . $row_user_fix['nama'] . '</h5>
                                
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label class="text-black font-weight-bold" for="nama">Nama Lengkap</label>
                                        <input readonly type="text" id="nama" class="form-control" value="' . $row_user_fix['nama'] . '" />
                                    </div>
                                   
                                  <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="jenis_kelamin">Jenis Kelamin</label>
                                                            <input readonly type="text" id="jenis_kelamin" class="form-control" value="' . $gender . '" />
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="pekerjaan">Nama Sekolah</label>
                                                            <input readonly type="text" id="pekerjaan" class="form-control" value="' . $row_user_fix['nama_sekolah'] . '" />
                                                        </div>
                                                        <div class="col-md-6 form-group">
                                                            <label for="type" class="font-weight-bold text-black">Suku dan Agama</label>
                                                            <input readonly type="text" id="suku_agama" class="form-control " value="'.$row_user_fix['suku_agama'].'" />
                                                        </div>
                                                       
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12 form-group">
                                                            <label class="text-black font-weight-bold" for="alamat">Alamat</label>
                                                            <input readonly type="text" id="alamat" class="form-control" value="' .  $row_user_fix['alamat'] . '" />
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="telepon">Nomor Telepon</label>
                                                            <input readonly type="text" id="telepon" class="form-control " value="'. $row_user_fix['telepon'].'" />
                                                        </div>
                                                        <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="pendidikan">Kelas</label>
                                                            <input readonly type="text" id="pendidikan" class="form-control " value="'. $row_user_fix['kelas'].'" />
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="row">
                                                      <div class="col-md-12 form-group">
                                                            <label class="text-black font-weight-bold" for="tempat_tanggal_lahir">Tempat, tanggal lahir</label>
                                                            <input readonly type="text" id="tempat_tanggal_lahir" class="form-control " value="'. $row_user_fix['tempat_tanggal_lahir'].'" />
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="row">
                                                        <div class="col-md-6 form-group">
                                                            <label for="type" class="font-weight-bold text-black">Anak ke</label>
                                                            <input readonly type="text" id="anak_ke" class="form-control " value="'. $row_user_fix['anak_ke'].'" />
                                                        </div>
                                                        <div class="col-md-6 form-group">
                                                            <label class="text-black font-weight-bold" for="warganegara">Warganegara</label>
                                                            <input readonly type="text" id="warganegara" class="form-control" value="'. $row_user_fix['warganegara'].'" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal2' . $row_user_fix['user_email'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel' . $row_user_fix['user_email'] . '" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel' . $row_user_fix['user_email'] . '">' . $row_user_fix['nama'] . '</h5>
                                                
                                            </div>
                                            <div class="modal-body">
                            <div class="col-md-6 form-group">
                                </div>                                                                                         
                                    <div class="form-group">
                                        <label for="formGroupExampleInput">Catatan</label>
                                        <textarea class="form-control" id="catatan" name="catatan"></textarea required>                                                               
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" id="save" data-dismiss="modal">Close</button>
                                         <button type="button" class="btn btn-danger" data-dismiss="modal">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td></tr>';




    }
     while ($row_user_fix = mysqli_fetch_assoc($query_user_dewasa_info)) {
                if ($row_user_fix['kelamin']) {
                    if ($row_user_fix['kelamin'] == '1') {
                        $gender = "Laki-Laki";
                    } else {
                        $gender = "Perempuan";
                    }
                } else {
                    $gender = "";
                }
                              echo '
<tr>
<td class="jadwal">' . $newFormatHari . " | " . $jam_awal . " - " . $jam_akhir . '</td>
<td class="nama_user">' . $row_user_fix['nama'] . '</td>
<td>
    <button type="button" class="btn btn-success margin small" data-toggle="modal" data-target="#exampleModal1' . $row_user_fix['user_email'] . '">Biodata</button>
</td>
<td>
    <button type="button" class="btn btn-primary margin small" data-toggle="modal" data-target="#exampleModal2' . $row_user_fix['user_email'] . '">Catatan</button>
</td>
<td>
    <a href="#exampleModal3' . $row_user_fix['user_email'] . '" class="trigger-btn" data-toggle="modal">
        <i class="fas fa-check fa-2x" style="color: green; "></i>
    </a>
</td>
<!-- Modal -->
<div class="modal fade" id="exampleModal1' . $row_user_fix['user_email'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel' . $row_user_fix['user_email'] . '" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel' . $row_user_fix['user_email'] . '">' . $row_user_fix['nama'] . '</h5>
                
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label class="text-black font-weight-bold" for="nama">Nama Lengkap</label>
                        <input readonly type="text" id="nama" class="form-control" value="' . $row_user_fix['nama'] . '" />
                    </div>
                   
                  <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="jenis_kelamin">Jenis Kelamin</label>
                                            <input readonly type="text" id="jenis_kelamin" class="form-control" value="' . $gender . '" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="pekerjaan">Pekerjaan</label>
                                            <input readonly type="text" id="pekerjaan" class="form-control" value="' . $row_user_fix['pekerjaan'] . '" />
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="type" class="font-weight-bold text-black">Suku dan Agama</label>
                                            <input readonly type="text" id="suku_agama" class="form-control " value="'.$row_user_fix['suku_agama'].'" />
                                        </div>
                                       
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label class="text-black font-weight-bold" for="alamat">Alamat</label>
                                            <input readonly type="text" id="alamat" class="form-control" value="' .  $row_user_fix['alamat'] . '" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="telepon">Nomor Telepon</label>
                                            <input readonly type="text" id="telepon" class="form-control " value="'. $row_user_fix['telepon'].'" />
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="pendidikan">Pendidikan</label>
                                            <input readonly type="text" id="pendidikan" class="form-control " value="'. $row_user_fix['pendidikan'].'" />
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                      <div class="col-md-12 form-group">
                                            <label class="text-black font-weight-bold" for="tempat_tanggal_lahir">Tempat, tanggal lahir</label>
                                            <input readonly type="text" id="tempat_tanggal_lahir" class="form-control " value="'. $row_user_fix['tempat_tanggal_lahir'].'" />
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label for="type" class="font-weight-bold text-black">Anak ke</label>
                                            <input readonly type="text" id="anak_ke" class="form-control " value="'. $row_user_fix['anak_ke'].'" />
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label class="text-black font-weight-bold" for="warganegara">Warganegara</label>
                                            <input readonly type="text" id="warganegara" class="form-control" value="'. $row_user_fix['warganegara'].'" />
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal2' . $row_user_fix['user_email'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel' . $row_user_fix['user_email'] . '" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel' . $row_user_fix['user_email'] . '">' . $row_user_fix['nama'] . '</h5>
                                
                            </div>
                            <div class="modal-body">
                            <div class="col-md-6 form-group">
                                </div>                                                                                         
                                    <div class="form-group">
                                        <label for="formGroupExampleInput">Catatan</label>
                                        <textarea class="form-control" id="catatan" name="catatan"></textarea required>                                                               
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" id="save" data-dismiss="modal">Close</button>
                                         <button type="button" class="btn btn-danger" data-dismiss="modal">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td></tr>';


    }
}
echo '</tbody></table></div></div>';
?>


<!DOCTYPE html>
<html lang="en">
<head>

    <!-- FONT AWESOME -->
    <script src="https://kit.fontawesome.com/acc3ee9eed.js" crossorigin="anonymous"></script>

    <!-- SWEET ALERT 2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- JQUERY -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <!-- Datatables CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css" />

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konselor Login - Griya Pulih Asih</title>
    <!-- ICON -->
    <link href="../assets/logo.png" rel="icon" />
    <style>
        .container {
            margin-top: 2vh;
            max-width: 1100px;
            width: 100%;
            background-color: #fff;
            padding: 1vw;
            margin-bottom: 4vh;
            border-radius: 10px;
            box-shadow: -10px 10px 19px 5px rgba(0, 0, 0, 0.4);
        }

        .mt-4 {
            margin-top: 1rem;
        }

        .dt-buttons .buttons-copy,
        .dt-buttons .buttons-csv,
        .dt-buttons .buttons-excel,
        .dt-buttons .buttons-pdf,
        .dt-buttons .buttons-print {
            background-color: darkmagenta;
            border-color: darkmagenta;
            color: #fff;
            border-radius: 5px;
        }

        .dt-buttons .buttons-copy:hover,
        .dt-buttons .buttons-csv:hover,
        .dt-buttons .buttons-excel:hover,
        .dt-buttons .buttons-pdf:hover,
        .dt-buttons .buttons-print:hover {
            background-color: lightgray;
            border-color: lightgray;
            color: black;
        }

        #tabelEvent {
            border-collapse: collapse;
            margin-top: 2vh;
            overflow-x: auto;
            table-layout: auto;
            margin-bottom: 2vh;
            text-align: center;
        }

        #tabelEvent td:nth-child(3) {
            text-align: justify;
        }

        #tabelEvent th,
        #tabelEvent td {
            padding: 1vh;
            border: 1px solid #ccc;
            white-space: normal;
        }

        #tabelEvent th {
            background-color: darkred;
            color: white;
            text-align: left;
        }

        #tabelEvent thead th {
            font-weight: bold;
        }

        #tabelEvent tbody tr:hover {
            cursor: pointer;
        }

        div.dataTables_wrapper div.dataTables_filter {
            margin-bottom: 2vh;
        }

        .table-responsive {
            overflow-x: auto;
        }

        @media screen and (max-width: 768px) {

            table {
                font-size: 12px;
            }

            h1 {
                font-size: 48px !important;
            }

            .dt-buttons .buttons-copy,
            .dt-buttons .buttons-csv,
            .dt-buttons .buttons-excel,
            .dt-buttons .buttons-pdf,
            .dt-buttons .buttons-print {
                font-size: 12px;
            }
        }
    </style>
    <style>
    body {
        /* background-image: url(../assets/halftone.png); */
        background-color: rgb(252, 193, 109);
        color: black;
        font-family: 'Roboto';
    }
    #hai{
        color: black;
        background-color: white;
        border: none;
        font-size: 30px;
        background-color: rgb(252, 193, 109);
    }
    #myTable{
        margin: 4vh;
        border: black;
        border-radius: 2px;
    }

    img {
        text-align: center;
    }

    .foto {
        text-align: center;
    }

    .bawah {
        margin-top: 35px;
    }

    .isibiodata {
        margin-bottom: 35px;
    }

    table {
        text-align: center;
    }

    .alerttop {
        margin-top: 20px;
        text-align: center;
    }

    .col-md-12 .alert a {
        display: inline-block;
    }

    textarea {
    resize: vertical;
}

</style>
</head>
<body>
                        
    
</body>
<script>
        $(document).ready(function() {

            var table = $('#tabelEvent').DataTable();

            function setPageSize() {
                var windowWidth = $(window).width();

                //Ukuran layar HP
                if (windowWidth <= 768) {
                    table.page.len(5).draw(); //Entri 5 per page
                } else { // Ukuran layar laptop
                    table.page.len(10).draw(); //Entri 10 per page
                }
            }

            setPageSize();

            $(window).on('resize', function() {
                setPageSize();
            });


            $(".view-poster-link").click(function(e) {
                e.preventDefault();
                var posterPath = $(this).data("poster");
                $("#eventPosterImage").attr("src", posterPath);
                $("#eventPosterModal").modal("show");
            });

        });
    </script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>

</html>