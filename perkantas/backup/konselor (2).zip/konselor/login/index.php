<?php
session_start();
require "../connect.php";
$err = 0;
$err_msg = '';

if(isset($_POST['save']))
{
    $konselor_email=$_POST['konselor_email'];
    $password=$_POST['password'];
    $sql=mysqli_query($con,"SELECT * FROM konselor_info where konselor_email='$konselor_email' and password='$password'");
    $row  = mysqli_fetch_array($sql);
    if(is_array($row))
    {
        $_SESSION["konselor_email"]=$row['konselor_email'];
        $_SESSION["password"]=$row['password'];      
        header("Location: ../main/index.php"); 
    }
    else
    {
      $err = 1;
      $err_msg = 'Wrong email / Password';
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<title>Konselor Site - Griya Pulih Asih</title>
<link href="../../assets/logo.png" rel="icon" />
<!-- FONT AWESOME -->
<script src="https://kit.fontawesome.com/acc3ee9eed.js" crossorigin="anonymous"></script>

<style>
    * {
          transition: .2s ease-in-out;
      }
    body{ 
			font: 14px; 
			background-size: 100%;
			background-position: center;
			background-repeat: no-repeat;
      background-attachment: fixed;
			background-color: rgb(252, 193, 109);
      width: 100vw;
      height: 100vh;
      }    
      
    .wrapper{ width: 360px; padding: 20px; margin:0 auto;}

    #page-container {
      position: relative;
      min-height: 90vh;
    }
    h2{
      text-align: center;
    }
    .mb-3{
      margin: 3%;
    }

    #content-wrap {
      padding-bottom: 2.5rem;
    }
    .wrapper{
      background-color: rgba(255, 255, 255, 0.3);
      color: black;
      opacity: 0.8;
      border-radius: 5%;
      
    }
    .form-group{
      color: black;
      border: black;
      text-align: center;
    }
    
</style>
<title></title>

</head>
<body>
  
<div id="page-container" style="margin-top: 100px">
  <div id="content-wrap">
    <div class="wrapper">    
    <form action="" method="post">
        <h2>Konselor Login</h2>
        <p class="hint-text"></p>
        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="text" class="form-control" name="konselor_email" onkeypress='return ((event.charCode >= 33 && event.charCode <= 38) || (event.charCode >= 40 && event.charCode <= 126)'>
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" name="password" onkeypress='return ((event.charCode >= 33 && event.charCode <= 38) || (event.charCode >= 40 && event.charCode <= 126)'>
        </div>
        <?php if($err == 1) { ?>
    <p style="color: red"><?php echo $err_msg; ?></p>
<?php } ?>
        <div class="form-group"> 
            <button type="submit" name="save" class="btn btn-outline-dark" style="width: 93%">Login</button>
        </div>
    </form>
  </div>
</body>