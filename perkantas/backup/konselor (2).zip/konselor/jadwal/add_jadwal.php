<?php
 if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

if (!isset ($_SESSION["konselor_email"])){
    header("location: login.php");
    exit();
}
include "../connect.php";

$query = mysqli_query($con, "SELECT * FROM konselor_info WHERE konselor_email='" . $_SESSION['konselor_email'] . "'"); 
$row = mysqli_fetch_assoc($query);

$id_konselor= $row['konselor_id'];
$tanggal = $_POST['tanggal'];
mysqli_query($con, "INSERT INTO konselor_jadwal VALUES (DEFAULT, " . $row['konselor_id'] . " , '" . $_POST['tanggal'] . "', '" . $_POST['jam_awal'] . "', '" . $_POST['jam_akhir'] . "', '0')");

echo "Jadwal Berhasil Ditambahkan ";
?>