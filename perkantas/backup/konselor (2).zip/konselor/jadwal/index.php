<?php
 if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

if (!isset ($_SESSION["konselor_email"])){
    header("location: login.php");
    exit();
}


include "../header.php";
include "../connect.php";
?>
<script src="../css/jquery.js"></script>
<script src="../css/bootstrap.js"></script>
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dosis&display=swap" rel="stylesheet">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300&display=swap" rel="stylesheet">
<style>
	body {
		background-image: url(../assets/halftone.png);
		font-family: 'Roboto';
	}

	div {
		display: block;
	}

	h1 {
		font-weight: bold;
		font-family: 'Titillium Web', sans-serif;
	}

	.row div {
		font-size: 18px;
	}
	.small {
		margin-top: 10px;
	}

	#save {
		margin-top: 10px;
	}
</style>
<div class="container">
	<h1>Tambah Jadwal Konseling</h1>
	<section class="section contact-section" id="next">
		<div class="row">
			<div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
				<form action="#" method="post" class="bg-white p-md-5 p-4 mb-5 border">
				<div class="row">
				<div class="col-md-4 form-group">
			        <label for="check_in" class="font-weight-bold text-black">Tanggal</label>
			        <input type="date" id="tanggal" class="form-control" required>
			    </div>
			</div>
					<div class="row">
						<div class="col-md-4 form-group">
							<label for="type" class="font-weight-bold text-black">Jam</label>
							<div class="field-icon-wrap">
								<div class="icon"><span class="ion-ios-arrow-down"></span></div>
								<!-- <select name="jam_awal" id="jam_awal" class="form-control" required>
									<option value="08:00:00">08.00 - 09.00 WIB</option>
									<option value="09:00:00">09.00 - 10.00 WIB</option>
									<option value="10:00:00">10.00 - 11.00 WIB</option>
									<option value="11:00:00">11.00 - 12.00 WIB</option>
									<option value="12:00:00">12.00 - 13.00 WIB</option>
									<option value="13:00:00">13.00 - 14.00 WIB</option>
									<option value="14:00:00">14.00 - 15.00 WIB</option>
								</select> -->
							</div>
								<div class="form-group .col-6 .col-sm-4">
									<div class="form-check">
										<input class="form-check-input" type="checkbox" value="08:00:00" id="cb0">
										<label class="form-check-label" for="jam_awal8">08.00 - 09.00 WIB</label>
									</div>
									<div class="form-check">
										<input class="form-check-input" type="checkbox" value="09:00:00" id="cb1">
										<label class="form-check-label" for="jam_awal9">09.00 - 10.00 WIB</label>
									</div>
									<div class="form-check">
										<input class="form-check-input" type="checkbox" value="10:00:00" id="cb2">
										<label class="form-check-label" for="jam_awal10">10.00 - 11.00 WIB</label>
									</div>
									<div class="form-check">
										<input class="form-check-input" type="checkbox" value="11:00:00" id="cb3">
										<label class="form-check-label" for="jam_awal11">11.00 - 12.00 WIB</label>
									</div>
									<div class="form-check">
										<input class="form-check-input" type="checkbox" value="12:00:00" id="cb4">
										<label class="form-check-label" for="jam_awal12">12.00 - 13.00 WIB</label>
									</div>
									<div class="form-check">
										<input class="form-check-input" type="checkbox" value="13:00:00" id="cb5">
										<label class="form-check-label" for="jam_awal13">13.00 - 14.00 WIB</label>
									</div>
									<div class="form-check">
										<input class="form-check-input" type="checkbox" value="14:00:00" id="cb6">
										<label class="form-check-label" for="jam_awal14">14.00 - 15.00 WIB</label>
									</div>
								</div>
						</div>
					</div>

			

					<div class="row">
						<div class="col-md-12 form-group">
							<button type="submit" value="Submit" id="save" class="btn btn-primary submit">Submit</button>
						</div>
					</div>

				</form>
			</div>
		</div>
	</section>
</div>


<script>
	$(document).ready(function() {
		$("#save").click(function(e) {
			var valid = this.form.checkValidity(); 
			// if (valid) {
				e.preventDefault(); 
				var tanggal = $('#tanggal').val(); 
				// var tanggalObjek = new Date(date); // Buat objek Date dari tanggal yang diambil

				// var tahun = tanggalObjek.getFullYear(); // Ambil tahun
				// var bulan = tanggalObjek.getMonth() + 1; // Ambil bulan (dimulai dari 0, jadi tambahkan 1)
				// var hari = tanggalObjek.getDate(); // Ambil hari
				// var tanggal = tahun + '/' + bulan + '/'+ hari;
				// var jam_awal = $('#jam_awal').val();

				cb = ['cb0', 'cb1', 'cb2', 'cb3', 'cb4', 'cb5', 'cb6']
				choose = []

				// alert(tanggal)



				for (let j = 0; j < cb.length; j++) {
					if ($('#'+cb[j]).is(':checked')) {
						// alert(cb[j]);
						choose.push($('#'+cb[j]).val())
					}
				}

				// alert(choose.length)

				for (let q = 0; q < choose.length; q++) {
					var jam_awal = choose[q]

					var waktuAwal = new Date(tanggal + ' ' + choose[q]);
					waktuAwal.setHours(waktuAwal.getHours() + 1);

					// alert(waktuAwal)

					// jam_awal sekarang telah ditambahkan 1 jam
					var jam_akhir = waktuAwal.getHours() + ':' + ('0' + waktuAwal.getMinutes()).slice(-2);
					
					// alert(tanggal)
					// alert(jam_awal)
					// alert(jam_akhir)
					
					$.ajax({
						url: 'add_jadwal.php',
						method: 'POST',
						data: {
							tanggal: tanggal,
							jam_awal: jam_awal,
							jam_akhir: jam_akhir
						},
						success: function(data) {
							// alert('bby')
							window.location.replace("../main/index.php");
						}
					});
				}
			// }
		});
	});
</script>
