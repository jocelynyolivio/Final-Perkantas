<?php
include 'connect.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once '../PHPMailer/PHPMailer.php';
require_once '../PHPMailer/SMTP.php';
require_once '../PHPMailer/Exception.php';

$user_email = $_POST['userEmail'];

$mail = new PHPMailer(true);
$otp = rand(100000, 999999);

// check table user_dewasa
$result_dewasa = mysqli_query($con, "SELECT * FROM user_dewasa_info WHERE user_email = '$user_email");

// check table user_anak
$result_anak = mysqli_query($con, "SELECT * FROM user_anak_info WHERE user_email = '$user_email'");

// check user
if (mysqli_num_rows($result_dewasa) === 1 || mysqli_num_rows($result_anak) === 1) {
    if (mysqli_num_rows($result_dewasa) === 1) {
        $result = $result_dewasa;
    } elseif (mysqli_num_rows($result_anak) === 1) {
        $result = $result_anak;
    }
    $row = mysqli_fetch_assoc($result);
    $email = $row['user_email'];

    $query = mysqli_query($con, "UPDATE `reset_verification` SET `reset_code` = '$otp', `reset_status` = '0' WHERE `user_email` = '$email'");

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    // $mail->SMTPDebug = 1;
    $mail->Username = 'jdemario31@gmail.com';
    $mail->Password = 'laoujmkuggofbyrw';
    $mail->Port = 465;
    $mail->SMTPSecure = "ssl";

    $mail->setFrom($mail->Username, 'OTP For Password Change');
    $mail->addAddress($email);

    $mail->isHTML(true);
    
    $mail->Subject = 'Kode OTP Ubah Password';
    $mail->Body    = 'Halo!<br>
                    Berikut kode OTP untuk melakukan reset password pada akun anda.<br>
                    <br>
                    Code: '.$otp.'<br>
                    <br>
                    Terimakasih.<br>
                        ';

    // Send mail   
    $mail->send();
    if (!$mail->send()) {
        // update user log
        $currentTimestamp = date('Y-m-d H:i:s');
        $activity = 'Request OTP gagal.';
        $sql = "INSERT INTO user_log (
            time, user_name, activity)
            VALUES (
                '$currentTimestamp','$email','$activity')";
        $stmt = $con -> prepare($sql);
        $stmt -> execute();
        // echo 'Email not sent an error was encountered: ' . $mail->ErrorInfo;
    } else {
        // echo 'Message has been sent.';
    }

    $mail->smtpClose();
} else {
    $em = "Akun tidak terdaftar. Silahkan daftarkan akun anda terlebih dahulu.";
    # response array
    $res = array('error' => 1, 'em'=> $em);
    echo json_encode($res);
    exit;
}

// update user log
$currentTimestamp = date('Y-m-d H:i:s');
$activity = 'Request OTP berhasil.';
$sql = "INSERT INTO user_log (
    time, user_name, activity)
    VALUES (
        '$currentTimestamp','$email','$activity')";
$stmt = $con -> prepare($sql);
$stmt -> execute();

$sm = "OTP telah terkirim. Silahkan cek email anda.";
# response array
$res = array('error' => 0, 'sm'=> $sm);
echo json_encode($res);
?>