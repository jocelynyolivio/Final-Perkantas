<?php 
    include "connect.php";
    $sql = "SELECT * FROM admin_info
            ORDER BY nama_admin ASC";
    $stmt = $con -> prepare($sql);
    $stmt -> execute();
    $result = $stmt -> get_result();
    $i = 1;
    while ($row = $result -> fetch_assoc()):
?>
    <tr>
        <td><?= $i?></td>
        <td class="nama text-break" style="padding-left: 30px;"><?= $row['nama_admin'] ?></td>
        <td class="aktv" style="padding-left: -40px;"><?= $row['admin_email'] ?></td>
    </tr>
    <?php $i++ ?>
<?php endwhile; ?>